#ifndef LIST
#define LIST
struct List {
	List* next = NULL;
	float value = NULL;
};
#endif
